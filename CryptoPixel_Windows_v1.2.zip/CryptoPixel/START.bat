@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto run
where py >nul 2>nul
if not errorlevel 1 (
  py -3 -m venv .venv
) else (
  python -m venv .venv
)
if errorlevel 1 goto no_python
:run
".venv\Scripts\python.exe" -c "import tkinter, websocket" >nul 2>nul
if not errorlevel 1 goto launch
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto fail
:launch
".venv\Scripts\python.exe" -c "import tkinter, websocket" >nul 2>nul
if errorlevel 1 goto fail
start "" ".venv\Scripts\pythonw.exe" "%~dp0crypto_pixel.py"
exit /b 0
:no_python
echo Python was not found or could not create a virtual environment.
echo Install Python 3.11 or newer from https://www.python.org/downloads/windows/
echo Select "Add Python to PATH" and include Tcl/Tk, then run START.bat again.
pause
exit /b 1
:fail
echo Setup failed. Check the error above and your Internet connection.
pause
exit /b 1
