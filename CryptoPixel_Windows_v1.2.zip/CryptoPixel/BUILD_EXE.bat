@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run START.bat once first, then close the widget.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m pip install "pyinstaller>=6,<7"
if errorlevel 1 goto fail
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onefile --windowed --name CryptoPixel crypto_pixel.py
if errorlevel 1 goto fail
echo Finished: dist\CryptoPixel.exe
explorer "%~dp0dist"
pause
exit /b 0
:fail
echo Build failed. Check the error above.
pause
exit /b 1
