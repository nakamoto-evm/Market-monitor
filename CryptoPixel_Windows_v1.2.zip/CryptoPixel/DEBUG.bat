@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run START.bat first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" crypto_pixel.py
pause
