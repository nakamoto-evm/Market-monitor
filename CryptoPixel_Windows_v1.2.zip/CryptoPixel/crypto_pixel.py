"""CryptoPixel: small native Tk desktop ticker. Public market data only."""
import json
import logging
from logging.handlers import RotatingFileHandler
import math
import os
from pathlib import Path
import random
import sys
import threading
import time
import tkinter as tk
from tkinter import messagebox

SYMBOLS = ('BTCUSDT', 'ETHUSDT', 'SOLUSDT')
ENDPOINTS = ('wss://data-stream.binance.vision', 'wss://stream.binance.com:443')
BG, FG, DIM = '#050d09', '#49ff83', '#38865a'
GLYPHS = {
'0':['01110','10001','10001','10001','10001','10001','01110'],
'1':['00100','01100','00100','00100','00100','00100','01110'],
'2':['01110','10001','00001','00010','00100','01000','11111'],
'3':['11110','00001','00001','01110','00001','00001','11110'],
'4':['00010','00110','01010','10010','11111','00010','00010'],
'5':['11111','10000','10000','11110','00001','00001','11110'],
'6':['01110','10000','10000','11110','10001','10001','01110'],
'7':['11111','00001','00010','00100','01000','01000','01000'],
'8':['01110','10001','10001','01110','10001','10001','01110'],
'9':['01110','10001','10001','01111','00001','00001','01110'],
'.':['0','0','0','0','0','1','1'], ',':['00','00','00','00','00','01','10'],
'-':['000','000','000','111','000','000','000'],
'B':['11110','10001','10001','11110','10001','10001','11110'],
'T':['11111','00100','00100','00100','00100','00100','00100'],
'C':['01111','10000','10000','10000','10000','10000','01111'],
'E':['11111','10000','10000','11110','10000','10000','11111'],
'H':['10001','10001','10001','11111','10001','10001','10001'],
'S':['01111','10000','10000','01110','00001','00001','11110'],
'O':['01110','10001','10001','10001','10001','10001','01110'],
'L':['10000','10000','10000','10000','10000','10000','11111'],
}

def pixels(text, x, y, step):
    """Shared dot-matrix geometry; no external font dependencies."""
    for ch in text:
        rows = GLYPHS[ch]
        for r, row in enumerate(rows):
            for c, bit in enumerate(row):
                if bit == '1':
                    yield (x+c*step, y+r*step, x+(c+1)*step-1, y+(r+1)*step-1)
        x += (len(rows[0])+1)*step

def parse_tick(raw):
    envelope = json.loads(raw)
    d = envelope.get('data', envelope)
    if d.get('s') not in SYMBOLS or d.get('e') not in ('24hrMiniTicker', 'aggTrade'):
        return None
    price = float(d['p'] if d['e'] == 'aggTrade' else d['c'])
    event = float(d['E']) / 1000
    if not math.isfinite(price) or price <= 0 or not math.isfinite(event):
        raise ValueError('Invalid market price or timestamp')
    return d['s'], price, event

class Feed:
    def __init__(self, mode='eco'):
        self.lock = threading.Lock()
        self.stop = threading.Event()
        self.restart = threading.Event()
        self.mode = mode
        self.latest = {}
        self.status = '正在连接行情…'
        self.connected = False
        self.thread = threading.Thread(target=self.run, daemon=True)

    def snapshot(self):
        with self.lock:
            return dict(self.latest), self.status, self.connected

    def state(self, status, connected=False):
        with self.lock:
            self.status, self.connected = status, connected

    def change(self, mode):
        self.mode = mode
        self.state('正在切换 / 重新连接…')
        self.restart.set()

    def run(self):
        import websocket
        attempt = 0
        while not self.stop.is_set():
            self.restart.clear()
            ws = None
            started = time.monotonic()
            try:
                stream = 'aggTrade' if self.mode == 'fast' else 'miniTicker'
                url = ENDPOINTS[attempt % len(ENDPOINTS)] + '/stream?streams=' + '/'.join(s.lower()+'@'+stream for s in SYMBOLS)
                self.state('正在连接行情…')
                ws = websocket.create_connection(url, timeout=8, enable_multithread=True)
                ws.settimeout(2)
                self.state('连接成功 · 等待报价', True)
                last = time.monotonic()
                while not self.stop.is_set() and not self.restart.is_set():
                    try:
                        raw = ws.recv()  # websocket-client replies to protocol ping frames.
                        if not raw:
                            raise ConnectionError('Connection closed')
                        tick = parse_tick(raw)
                        if tick:
                            symbol, price, event = tick
                            with self.lock:
                                old = self.latest.get(symbol)
                                if not old or event >= old[2]:
                                    self.latest[symbol] = (price, time.monotonic(), event)
                            last = time.monotonic()
                            attempt = 0
                    except websocket.WebSocketTimeoutException:
                        pass
                    if time.monotonic()-last > 20:
                        raise TimeoutError('No market data for 20 seconds')
            except Exception as exc:
                logging.warning('Feed failure: %s: %s', type(exc).__name__, exc)
            finally:
                if ws:
                    try:
                        ws.close(timeout=1)
                    except Exception:
                        pass
                self.state('连接已断开 · 保留最后报价')
            if self.stop.is_set():
                break
            if self.restart.is_set():
                continue
            delay = min(30, 2 ** min(attempt+1, 5)) + random.random()
            attempt += 1
            self.state(f'连接中断 · {int(delay)} 秒后重试')
            self.restart.wait(delay)

def text_width(text, step):
    # Exclude the trailing inter-character space; digits remain tabular width.
    return (sum(len(GLYPHS[ch][0])+1 for ch in text)-1)*step-1


def layout_plan(layout, scale, values):
    pad, gap = 8, 20
    steps = [min(3, 184 / (text_width(v, 1)+1)) for v in values]
    widths = [text_width(v, st) for v, st in zip(values, steps)]
    labels = [text_width(s[:-4], 2) for s in SYMBOLS]
    groups = [lw+10+pw if layout=='line' else max(lw,pw) for lw,pw in zip(labels,widths)]
    height = 36 if layout=='line' else 56
    width = max(groups)+pad*2 if layout=='vertical' else sum(groups)+gap*2+pad*2
    entries = []
    x = pad
    for i,(lw,pw,gw,step) in enumerate(zip(labels,widths,groups,steps)):
        y = i*height if layout=='vertical' else 0
        if layout=='vertical':
            x = (width-gw)/2
        if layout=='line':
            label = (x, (height-13)/2, 2)
            price = (x+lw+10, (height-(7*step-1))/2, step)
        else:
            label = (x+(gw-lw)/2, y+7, 2)
            price = (x+(gw-pw)/2, y+28, step)
        entries.append((label,price))
        x += gw+gap
    return math.ceil(width*scale), math.ceil(height*(3 if layout=='vertical' else 1)*scale), entries

class App:
    def __init__(self, root, folder):
        self.root, self.folder = root, folder
        self.config = {}
        try:
            config = json.loads((folder/'settings.json').read_text('utf-8'))
            if isinstance(config, dict):
                self.config = config
        except (OSError, ValueError):
            pass
        self.mode = tk.StringVar(value='fast' if self.config.get('mode') == 'fast' else 'eco')
        self.top = tk.BooleanVar(value=bool(self.config.get('top', True)))
        layout = self.config.get('layout', 'horizontal')
        self.layout = tk.StringVar(value=layout if layout in ('horizontal','vertical','line') else 'horizontal')
        size = self.config.get('scale', 1.0)
        self.scale = tk.DoubleVar(value=size if size in (.8,1.0,1.25,1.5) else 1.0)
        self.borderless = tk.BooleanVar(value=bool(self.config.get('borderless', True)))
        self.feed = Feed(self.mode.get())
        self.drawn = {}
        self.drag_origin = None
        root.title('CryptoPixel')
        root.configure(bg=BG)
        root.resizable(False, False)
        root.attributes('-topmost', self.top.get())
        root.overrideredirect(self.borderless.get())
        root.protocol('WM_DELETE_WINDOW', self.close)
        self.canvas = tk.Canvas(root,bg=BG,highlightthickness=0,bd=0)
        self.canvas.pack()
        self.menu = tk.Menu(root,tearoff=0)
        layouts = tk.Menu(self.menu,tearoff=0)
        for label,value in [('横向紧凑（币种在上）','horizontal'),('横向单行（最矮）','line'),('竖向排列','vertical')]:
            layouts.add_radiobutton(label=label,variable=self.layout,value=value,command=self.relayout)
        self.menu.add_cascade(label='显示布局',menu=layouts)
        sizes = tk.Menu(self.menu,tearoff=0)
        for label,value in [('小号 · 80%',.8),('标准 · 100%',1.0),('大号 · 125%',1.25),('特大 · 150%',1.5)]:
            sizes.add_radiobutton(label=label,variable=self.scale,value=value,command=self.relayout)
        self.menu.add_cascade(label='显示大小',menu=sizes)
        self.menu.add_checkbutton(label='无边框沉浸显示（F2）',variable=self.borderless,command=self.toggle_border)
        self.menu.add_checkbutton(label='始终置顶',variable=self.top,command=self.toggle_top)
        self.menu.add_separator()
        self.menu.add_radiobutton(label='均衡：约 1 秒推送',variable=self.mode,value='eco',command=self.change_mode)
        self.menu.add_radiobutton(label='极速：实时成交 / 250ms 界面',variable=self.mode,value='fast',command=self.change_mode)
        self.menu.add_command(label='重新连接',command=lambda:self.feed.change(self.mode.get()))
        self.menu.add_command(label='连接状态',command=self.connection_info)
        self.menu.add_command(label='使用说明',command=self.about)
        self.menu.add_separator()
        self.menu.add_command(label='退出',command=self.close)
        root.bind('<Button-3>',self.popup)
        self.canvas.bind('<ButtonPress-1>',self.drag_start)
        self.canvas.bind('<B1-Motion>',self.drag_move)
        self.canvas.bind('<ButtonRelease-1>',lambda e:self.save())
        root.bind('<F2>',self.key_border)
        root.bind('<Escape>',self.show_border)
        root.bind('<Alt-F4>',lambda e:self.close())
        self.relayout(save=False)
        try:
            x,y = int(self.config['x']), int(self.config['y'])
            if 0 <= x < root.winfo_screenwidth()-80 and 0 <= y < root.winfo_screenheight()-30:
                root.geometry(f'+{x}+{y}')
        except (KeyError, ValueError, TypeError):
            root.geometry('+60+60')
        self.feed.thread.start()
        self.update()

    def relayout(self, save=True):
        self.plan_key = None
        self.drawn.clear()
        if save:
            self.save()
        self.render()

    def drag_start(self,event):
        self.root.focus_force()
        self.drag_origin=(event.x_root,event.y_root,self.root.winfo_x(),self.root.winfo_y())

    def drag_move(self,event):
        if self.drag_origin:
            px,py,x,y=self.drag_origin
            self.root.geometry(f'{x+event.x_root-px:+d}{y+event.y_root-py:+d}')

    def popup(self,event):
        self.root.focus_force()
        try:
            self.menu.tk_popup(event.x_root,event.y_root)
        finally:
            self.menu.grab_release()

    def toggle_border(self):
        self.root.overrideredirect(self.borderless.get())
        self.root.attributes('-topmost',self.top.get())
        self.save()

    def key_border(self,event=None):
        self.borderless.set(not self.borderless.get())
        self.toggle_border()

    def show_border(self,event=None):
        self.borderless.set(False)
        self.toggle_border()

    def toggle_top(self):
        self.root.attributes('-topmost',self.top.get())
        self.save()

    def change_mode(self):
        self.feed.change(self.mode.get())
        self.save()

    def save(self):
        try:
            data = {'mode':self.mode.get(),'top':self.top.get(),'x':self.root.winfo_x(),'y':self.root.winfo_y(),
                    'layout':self.layout.get(),'scale':self.scale.get(),'borderless':self.borderless.get()}
            temp = self.folder/'settings.tmp'
            temp.write_text(json.dumps(data),'utf-8')
            temp.replace(self.folder/'settings.json')
        except OSError:
            logging.exception('Unable to save settings')

    def connection_info(self):
        latest,status,connected=self.feed.snapshot()
        lines=[status,'计价：USDT · Binance 现货']
        for symbol in SYMBOLS:
            tick=latest.get(symbol)
            lines.append(symbol[:-4]+(f'：{int(time.monotonic()-tick[1])} 秒前收到报价' if tick else '：暂无报价'))
        messagebox.showinfo('连接状态','\n'.join(lines),parent=self.root)

    def about(self):
        messagebox.showinfo('CryptoPixel v1.2',
            '按住窗口任意位置拖动；右键打开设置。\n横向紧凑 / 横向单行 / 竖向；四档大小。\n'
            'F2 切换边框；Esc 恢复标题栏；右键可退出。\n\n'
            '按价格宽度紧凑排列，币种与价格居中。\n只显示币种和价格，计价单位 USDT。\n'
            '断线或超过 10 秒未更新时变暗，保留最后报价。\n'
            '无报价时显示横杠；详细状态在右键菜单。\n'
            '无边框时可能不显示任务栏入口，需要最小化时先恢复标题栏。',parent=self.root)

    def render(self):
        latest, status, connected = self.feed.snapshot()
        now = time.monotonic()
        scale=self.scale.get()
        values=[f'{latest[s][0]:,.2f}' if s in latest else '---.--' for s in SYMBOLS]
        width,height,entries=layout_plan(self.layout.get(),scale,values)
        plan_key=(width,height,entries)
        if self.plan_key != plan_key:
            self.canvas.config(width=width,height=height)
            self.root.geometry(f'{width}x{height}')
            self.canvas.delete('all')
            self.drawn.clear()
            self.plan_key=plan_key
        for i,symbol in enumerate(SYMBOLS):
            tick=latest.get(symbol)
            stale=bool(tick and (now-tick[1]>10 or time.time()-tick[2]>10 or not connected))
            value=f'{tick[0]:,.2f}' if tick else '---.--'
            color=DIM if stale or not tick else FG
            key=(value,color)
            if self.drawn.get(symbol)==key:
                continue
            self.canvas.delete(symbol)
            label,price=entries[i]
            for text,(tx,ty,size) in [(symbol[:-4],label),(value,price)]:
                for box in pixels(text,tx,ty,size):
                    self.canvas.create_rectangle(*(v*scale for v in box),fill=color,width=0,tags=symbol)
            self.drawn[symbol]=key

    def update(self):
        self.render()
        delay=1000 if self.root.state()=='iconic' else (250 if self.mode.get()=='fast' else 500)
        self.root.after(delay,self.update)

    def close(self):
        self.save()
        self.feed.stop.set()
        self.feed.restart.set()
        self.root.destroy()

def main():
    folder = Path(os.environ.get('LOCALAPPDATA',str(Path.home()))) / 'CryptoPixel'
    folder.mkdir(parents=True,exist_ok=True)
    handler = RotatingFileHandler(folder/'app.log',maxBytes=200_000,backupCount=2,encoding='utf-8')
    logging.basicConfig(level=logging.WARNING,handlers=[handler],format='%(asctime)s %(message)s')
    if sys.platform=='win32':
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass
    root = tk.Tk()
    try:
        import websocket
    except ImportError:
        root.withdraw()
        messagebox.showerror('缺少依赖','请先运行 START.bat，自动安装所需依赖。')
        root.destroy()
        return
    App(root,folder)
    root.mainloop()

if __name__=='__main__':
    try:
        main()
    except Exception:
        logging.exception('Startup failed')
        try:
            messagebox.showerror('启动失败','请运行 START.bat 查看错误，或查看 %LOCALAPPDATA%\\CryptoPixel\\app.log。')
        except Exception:
            pass
        raise
